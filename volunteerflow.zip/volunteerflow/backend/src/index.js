const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true
}));
app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    message: 'VolunteerFlow Backend is running!'
  });
});

app.get('/api', (req, res) => {
  res.json({ 
    message: 'VolunteerFlow API v1.0.0',
    endpoints: {
      health: '/health',
      api: '/api'
    }
  });
});

app.listen(PORT, () => {
  console.log('\n✅ VolunteerFlow Backend Started!');
  console.log(`🚀 Server: http://localhost:${PORT}`);
  console.log(`🏥 Health: http://localhost:${PORT}/health`);
  console.log(`📚 API: http://localhost:${PORT}/api\n`);
});