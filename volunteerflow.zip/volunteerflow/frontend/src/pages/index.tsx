import React from 'react';
import Head from 'next/head';

export default function Home() {
  const [apiStatus, setApiStatus] = React.useState('Checking...');

  React.useEffect(() => {
    fetch('http://localhost:3001/health')
      .then(res => res.json())
      .then(data => setApiStatus('✅ Connected'))
      .catch(() => setApiStatus('❌ Backend not running'));
  }, []);

  return (
    <>
      <Head>
        <title>VolunteerFlow</title>
      </Head>
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
      }}>
        <div style={{ textAlign: 'center', color: 'white', padding: '20px' }}>
          <h1 style={{ fontSize: '4rem', fontWeight: 'bold', marginBottom: '1rem' }}>
            VolunteerFlow
          </h1>
          <p style={{ fontSize: '1.5rem', marginBottom: '2rem', opacity: 0.9 }}>
            Volunteer Management Platform
          </p>
          <div style={{
            padding: '1rem 2rem',
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '10px',
            marginBottom: '2rem'
          }}>
            <p>Backend API: {apiStatus}</p>
          </div>
          <button style={{
            background: 'white',
            color: '#667eea',
            padding: '1rem 2rem',
            borderRadius: '8px',
            border: 'none',
            fontSize: '1.1rem',
            fontWeight: '600',
            cursor: 'pointer',
            boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
          }}>
            Get Started
          </button>
        </div>
      </div>
    </>
  );
}