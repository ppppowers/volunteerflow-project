# VolunteerFlow

Volunteer Management Platform

## 🚀 Quick Start (WITHOUT Docker)

### Backend
```powershell
cd backend
npm install
npm start
```

### Frontend (in new terminal)
```powershell
cd frontend
npm install
npm run dev
```

### Access
- Frontend: http://localhost:3000
- Backend: http://localhost:3001/health

## 🐳 With Docker (Optional)

```powershell
docker-compose up --build
```

## ✅ Verify It Works

1. Backend: Open http://localhost:3001/health
   - Should see: {"status":"ok"}

2. Frontend: Open http://localhost:3000
   - Should see: VolunteerFlow homepage with green checkmark

## 📁 Project Structure

```
volunteerflow/
├── backend/         # Express API
├── frontend/        # Next.js App
└── docker-compose.yml
```

## 🛠️ Tech Stack

- Backend: Node.js + Express
- Frontend: Next.js + React
- Database: PostgreSQL (optional)